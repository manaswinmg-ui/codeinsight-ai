def add(a, b):
    return a + b

def divide(a, b):
    # TODO: check division by zero
    return a / b
