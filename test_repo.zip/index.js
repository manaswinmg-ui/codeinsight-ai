function calculate(x) {
    let result = x * 2;
    console.log(result);
    return result;
}
